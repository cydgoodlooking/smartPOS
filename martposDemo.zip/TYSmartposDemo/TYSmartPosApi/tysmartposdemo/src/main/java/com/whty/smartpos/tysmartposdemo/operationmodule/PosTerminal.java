package com.whty.smartpos.tysmartposdemo.operationmodule;

import com.whty.smartpos.tysmartposapi.OperationResult;
import com.whty.smartpos.tysmartposapi.pos.DeviceInfo;
import com.whty.smartpos.tysmartposapi.pos.DeviceVersion;
import com.whty.smartpos.tysmartposapi.pos.deviceupdate.HardwareUpgradeListener;

/**
 * Created by zengyahui on 2017-10-26.
 */

public class PosTerminal extends OperationInter {

    @Override
    public String execute(int index) {
        result.delete(0, result.length());
        switch (index) {
            case 0:
                result.append(">>> getDeviceSN <<<\n");
                String sn = smartPosApi.getDeviceSN();
                result.append("device sn : " + sn + "\n");
                break;
            case 1:
                result.append(">>> getDevicePN <<<\n");
                OperationResult operationResult = smartPosApi.getDevicePN();
                result.append("status code : " + operationResult.getStatusCode() + "\n");
                result.append("data : " + operationResult.getData() + "\n");
                break;
            case 2:
                result.append(">>> getDeviceKSN <<<\n");
                operationResult = smartPosApi.getDeviceKSN();
                result.append("status code : " + operationResult.getStatusCode() + "\n");
                result.append("data : " + operationResult.getData() + "\n");
                break;
            case 3:
                result.append(">>> getDeviceVersion <<<\n");
                DeviceVersion deviceVersion = smartPosApi.getDeviceVersion();
                result.append("android version : " + deviceVersion.getAndroidVersion() + "\n");
                result.append("custom version : " + deviceVersion.getCustomVersion() + "\n");
                result.append("posservice version : " + deviceVersion.getPosServiceVersion() + "\n");
                result.append("boot version : " + deviceVersion.getBootVerion() + "\n");
                result.append("soft version : " + deviceVersion.getSoftVersion() + "\n");
                result.append("sub version : " + deviceVersion.getSubVersion() + "\n");
                break;
            case 4:
                result.append(">>> getDeviceInfo <<<\n");
                DeviceInfo deviceInfo = smartPosApi.getDeviceInfo();
                result.append("vendor : " + deviceInfo.getVendor() + "\n");
                result.append("model : " + deviceInfo.getModel() + "\n");
                break;
            case 5:
                result.append(">>> getMerchantAndTerminalNo <<<\n");
                String[] data = smartPosApi.getMerchantAndTerminalNo();
                if (data != null && data.length > 0) {
                    result.append("merchant number : " + data[0] + "\n");
                    result.append("terminal number : " + data[1] + "\n");
                } else {
                    result.append("getMerchantAndTerminalNo error " + data + "\n");
                }
                break;
            case 6:
                result.append(">>> updateMerchantAndTerminalNo <<<\n");
                result.append("param merchant number : " + "123456789123456" + "\n");
                result.append("param terminal number : " + "12345678" + "\n");
                int res = smartPosApi.updateMerchantAndTerminalNo("123456789123456", "12345678");
                result.append("result : " + res + "\n");
                break;
            case 7:
                result.append(">>> getBatchAndFlowNo <<<\n");
                data = smartPosApi.getBatchAndFlowNo();
                if (data != null && data.length > 0) {
                    result.append("batch number : " + data[0] + "\n");
                    result.append("flow number : " + data[1] + "\n");
                } else {
                    result.append("getBatchAndFlowNo error " + data + "\n");
                }
                break;
            case 8:
                result.append(">>> updateMerchantAndTerminalNo <<<\n");
                result.append("param batch number : " + "000001" + "\n");
                result.append("param flow number : " + "123456" + "\n");
                res = smartPosApi.updateBatchAndFlowNo("000001", "123456");
                result.append("result : " + res + "\n");
                break;
            case 9:
                result.append(">>> installApp <<<\n");
                result.append("param app name : " + "HttpsTest" + "\n");
                boolean ret = smartPosApi.installApp("/system/data/HttpsTest.apk");
                result.append("result : " + ret + "\n");
                break;
            case 10:
                result.append(">>> uninstallApp <<<\n");
                result.append("param package name : " + "com.whty.smartpos.httpstest" + "\n");
                ret = smartPosApi.uninstallApp("com.whty.smartpos.httpstest");
                result.append("result : " + ret + "\n");
                break;
            case 11:
                result.append(">>> upgradeDevice <<<\n");
                smartPosApi.upgradeDevice(null, null, new MyHardwareUpgradeListener());
                break;
            case 12:
                result.append(">>> setSystemClock <<<\n");
                ret = smartPosApi.setSystemClock("20080808080808");
                result.append("result : " + ret + "\n");
                break;
            case 13:
                try {
                    result.append(">>> reboot <<<\n");
                    smartPosApi.reboot();
                } catch (Exception e) {
                    result.append(e.getMessage() + "\n");
                }
                break;
            case 14:
                try {
                    result.append(">>> setAPN <<<\n");
                    ret = smartPosApi.setAPN("天喻专用APN", "tianyu", "", "");
                    result.append("result : " + ret + "\n");
                } catch (Exception e) {
                    result.append(e.getMessage() + "\n");
                }
                break;
            case 15:
                result.append(">>> writeCustomData <<<\n");
                result.append("param positon : " + 0 + "\n");
                result.append("param data : " + "123456" + "\n");
                res = smartPosApi.writeCustomData(0, "123456");
                result.append("result : " + res + "\n");
                break;
            case 16:
                result.append(">>> readCustomData <<<\n");
                result.append("param positon : " + 0 + "\n");
                operationResult = smartPosApi.readCustomData(0);
                result.append("status code : " + operationResult.getStatusCode() + "\n");
                result.append("data : " + operationResult.getData() + "\n");
                break;
            case 17:
                result.append(">>> transceive <<<\n");
                result.append("param cmd : " + "fe01010600" + "\n");
                operationResult = smartPosApi.transceive("fe01010600");
                result.append("status code : " + operationResult.getStatusCode() + "\n");
                result.append("data : " + operationResult.getData() + "\n");
                break;
        }
        return result.toString();
    }

    class MyHardwareUpgradeListener implements HardwareUpgradeListener {

        @Override
        public void upgradeDeviceSuccess() {

        }

        @Override
        public void upgradeDeviceStart(byte type) {

        }

        @Override
        public void showProgress(byte type, int progressValue) {

        }

        @Override
        public void upgradeFail(int errorCode) {

        }

        @Override
        public void showVersion(boolean mainFlag, String currentVersion, String targetVersion) {

        }

        @Override
        public void error(String msg) {

        }

        @Override
        public void updateMainTime(long time1, long time2, long time3) {

        }

        @Override
        public void updateChildTime(long time) {

        }

        @Override
        public void isUpdate(byte type, boolean isSuccess) {

        }
    }
}
