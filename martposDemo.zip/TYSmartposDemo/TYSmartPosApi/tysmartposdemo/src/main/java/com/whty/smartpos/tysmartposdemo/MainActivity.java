package com.whty.smartpos.tysmartposdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.whty.smartpos.tysmartposapi.ITYSmartPosApi;
import com.whty.smartpos.tysmartposdemo.operationmodule.MyListener;
import com.whty.smartpos.tysmartposdemo.operationmodule.OperationInter;
import com.whty.smartpos.tysmartposdemo.operationmodule.PinPadDevice;
import com.whty.smartpos.tysmartposdemo.operationmodule.ScannerDevice;

public class MainActivity extends Activity {

    public static ITYSmartPosApi smartPosApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        smartPosApi = ITYSmartPosApi.get(this);
        smartPosApi.setListener(new MyListener());
        OperationInter.setActivity(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK || resultCode == 20) {
            if (requestCode == 0) {
                String statusCode = data.getStringExtra("statusCode");
                String pinblock = data.getStringExtra("pinblock");
                Log.d("MainActivity", "pinblock : " + pinblock);
            } else if (requestCode == 1) {
                ScannerDevice.scanData = data.getStringExtra("SCAN_RESULT");
                Log.d("MainActivity", ScannerDevice.scanData);
            }
        }
    }
}
