package com.whty.smartpos.tysmartposdemo.operationmodule;

import com.whty.smartpos.tysmartposapi.OperationResult;
import com.whty.smartpos.tysmartposapi.cardreader.CardInfo;
import com.whty.smartpos.tysmartposapi.cardreader.CardReaderConstrants;

/**
 * Created by zengyahui on 2017-10-26.
 */

public class CardReaderDevice extends OperationInter {

    @Override
    public String execute(int index) {
        result.delete(0, result.length());
        switch (index) {
            case 0:
                result.append(">>> setReadCardConfig <<<\n");
                result.append("param msr : " + true + "\n");
                result.append("param ic : " + true + "\n");
                result.append("param contactlessIc : " + true + "\n");
                smartPosApi.setReadCardConfig(true, true, true);
                break;
            case 1:
                result.append(">>> readCard <<<\n");
                result.append("param amount : " + "1" + "\n");
                result.append("param tradeTime : " + "20171026101010" + "\n");
                result.append("param tradeType : " + 0 + "\n");
                result.append("param swipeTimeout : " + 60 + "\n");
                CardInfo cardInfo = smartPosApi.readCard("1", "20171026101010", (byte) 0, (byte) 60);
                result.append("card information : " + cardInfo.toString() + "\n");
                break;
            case 2:
                result.append(">>> tradeResponse <<<\n");
                int res = smartPosApi.tradeResponse(null, null);
                result.append("result : " + res + "\n");
                break;
            case 3:
                result.append(">>> cancelReadCard <<<\n");
                boolean rec = smartPosApi.cancelReadCard();
                result.append("result : " + rec + "\n");
                break;
            case 4:
                result.append(">>> startSearchCard <<<\n");
                res = smartPosApi.startSearchCard(true, true, true, 60);
                result.append("card type : " + res + "\n");
                break;
            case 5:
                result.append(">>> stopSearchCard <<<\n");
                res = smartPosApi.stopSearchCard();
                result.append("resut : " + res + "\n");
                break;
            case 6:
                result.append(">>> getMagCardData <<<\n");
                cardInfo = smartPosApi.getMagCardData();
                result.append("card information : " + cardInfo.toString() + "\n");
                break;
            case 7:
                result.append(">>> powerOn <<<\n");
                OperationResult operationResult = smartPosApi.powerOn();
                result.append("status : " + operationResult.getStatusCode() + "\n");
                result.append("atr : " + operationResult.getData() + "\n");
                break;
            case 8:
                result.append(">>> powerOff <<<\n");
                res = smartPosApi.powerOff();
                result.append("result : " + res + "\n");
                break;
            case 9:
                result.append(">>> active <<<\n");
                res = smartPosApi.active();
                result.append("result : " + res + "\n");
                break;
            case 10:
                result.append(">>> halt <<<\n");
                res = smartPosApi.halt();
                result.append("result : " + res + "\n");
                break;
            case 11:
                result.append(">>> isCardExists <<<\n");
                res = smartPosApi.isCardExists();
                result.append("isCardExists : " + res + "\n");
                break;
            case 12:
                result.append(">>> transmitIC <<<\n");
                operationResult = smartPosApi.transmitIC(new byte[]{
                        0x00, (byte) 0xa4, 0x04, 0x00, 0x08, (byte) 0xa0, 0x00, 0x00, 0x03, 0x33, 0x01, 0x01, 0x02});
                result.append("status : " + operationResult.getStatusCode() + "\n");
                result.append("data : " + operationResult.getData() + "\n");
                break;
            case 13:
                result.append(">>> transmitRF <<<\n");
                operationResult = smartPosApi.transmitRF(new byte[]{
                        0x00, (byte) 0xa4, 0x04, 0x00, 0x0e, 0x32, 0x50, 0x41, 0x59, 0x2e, 0x53, 0x59, 0x53, 0x2e, 0x44, 0x44, 0x46, 0x30, 0x31});
                result.append("status : " + operationResult.getStatusCode() + "\n");
                result.append("data : " + operationResult.getData() + "\n");
                break;
            case 14:
                result.append(">>> openPSAMCard <<<\n");
                result.append("param id : " + CardReaderConstrants.PSAM_CARD_2 + "\n");
                operationResult = smartPosApi.openPSAMCard(CardReaderConstrants.PSAM_CARD_2);
                result.append("status : " + operationResult.getStatusCode() + "\n");
                result.append("data : " + operationResult.getData() + "\n");
                break;
            case 15:
                result.append(">>> closePSAMCard <<<\n");
                result.append("param id : " + CardReaderConstrants.PSAM_CARD_2 + "\n");
                res = smartPosApi.closePSAMCard(CardReaderConstrants.PSAM_CARD_2);
                result.append("result : " + res + "\n");
                break;
            case 16:
                result.append(">>> transmitPSAM <<<\n");
                result.append("param id : " + CardReaderConstrants.PSAM_CARD_2 + "\n");
                operationResult = smartPosApi.transmitPSAM(CardReaderConstrants.PSAM_CARD_2, new byte[]{0x00, 0x00, 0x00});
                result.append("status : " + operationResult.getStatusCode() + "\n");
                result.append("data : " + operationResult.getData() + "\n");
                break;
        }
        return result.toString();
    }
}
